package org.example.mutantes.exception;

public class DnaHashCalculationException extends RuntimeException {

    public DnaHashCalculationException(String message, Throwable cause) {
        super(message, cause);
    }
}